import json
from pathlib import Path

import pytest

from bionexus.adapters.lab.recording import PlaybackLab, RecordingLab
from bionexus.adapters.lab.simulator import SimulatorLab
from bionexus.adapters.models.anthropic_provider import AnthropicProvider
from bionexus.adapters.sandbox.agentenv import AgentEnvClient, AgentEnvSandbox
from bionexus.adapters.store.sqlite import SqliteProvenanceStore
from bionexus.core.contracts import (
    Envelope,
    ProtocolOp,
    ProtocolStep,
    ProtocolSubmission,
    ReagentSpec,
    SampleKind,
    SampleSpec,
    ToolInvocation,
)
from bionexus.core.flywheel import FlywheelLog
from bionexus.core.interfaces import system_actor
from bionexus.core.safety import SafetyEngine, LabGateway

BRANCH = "b-ext"
RECORD = Path("tests/_recording.json")


def env() -> Envelope:
    return Envelope(experiment_branch_id=BRANCH)


def make_protocol():
    return ProtocolSubmission(
        envelope=env(),
        title="t",
        assay_type="binding",
        steps=[ProtocolStep(seq=1, op=ProtocolOp.dispense)],
        samples=[SampleSpec(sample_id="C1", kind=SampleKind.compound)],
        reagents=[ReagentSpec(name="buffer", amount="1 mL", bsl_level=1)],
    )


# ---- T3.3 recording / playback (P8) ------------------------------------------

def test_recording_then_playback_identical(tmp_path):
    record_path = tmp_path / "session.json"
    rec = RecordingLab(SimulatorLab(seed=7), record_path)
    gw_rec = LabGateway(rec, SafetyEngine(), SqliteProvenanceStore(), system_actor())
    p = make_protocol()
    run_id, _ = gw_rec.submit(p)
    result_rec = rec.fetch_results(run_id)
    rec.list_capabilities()
    rec.save()

    playback = PlaybackLab(record_path)
    assert playback.list_capabilities() == SimulatorLab(seed=7).list_capabilities()
    assert playback.submit_protocol(p) == run_id
    result_pb = playback.fetch_results(run_id)
    assert [m.value for m in result_pb.measurements] == [m.value for m in result_rec.measurements]


def test_playback_rejects_unrecorded_protocol(tmp_path):
    path = tmp_path / "s.json"
    rec = RecordingLab(SimulatorLab(seed=1), path)
    rec.submit_protocol(make_protocol())
    rec.save()
    playback = PlaybackLab(path)
    with pytest.raises(LookupError):
        playback.submit_protocol(make_protocol())  # different protocol_id


# ---- T4.1 anthropic provider (P3) ---------------------------------------------

def test_anthropic_stub_deterministic():
    provider = AnthropicProvider()  # no api key -> stub
    inv = ToolInvocation(envelope=env(), tool="c.fm.generate_molecules")
    r1 = provider.generate(inv, "prompt", n=2)
    r2 = provider.generate(inv, "prompt", n=2)
    assert r1.output["text"] == r2.output["text"]
    json.loads(r1.output["text"])
    assert r1.model_version == "stub-claude"


# ---- T4.2 AgentENV sandbox (P7) -------------------------------------------------

class _FakeTransport:
    """Contract test stand-in for the AgentENV server."""
    def __init__(self):
        self.calls = []
        self._n = 0

    def _request(self, method, path, body=None):
        self.calls.append((method, path))
        if method == "POST" and path == "/sandboxes":
            self._n += 1
            return {"sandboxID": f"sbx-{self._n}"}
        return {}


def test_agentenv_sandbox_snapshot_fork(monkeypatch):
    from bionexus.adapters.sandbox import agentenv as mod

    store = SqliteProvenanceStore()
    client = AgentEnvClient("http://localhost:0")
    transport = _FakeTransport()
    monkeypatch.setattr(client, "_request", transport._request)

    sbx = AgentEnvSandbox(client, "root", store=store, actor=system_actor())
    snap = sbx.snapshot()
    child = sbx.fork(snap)
    assert child.branch_id.startswith("root/")
    assert ("POST", "/sandboxes/sbx-1/pause") in transport.calls
    assert any(m == "POST" and path.endswith("/resume") for m, path in transport.calls)
    events = {r.event_type for r in store.branch_records(child.branch_id)}
    assert "sandbox_fork" in {e.value for e in events}


# ---- T4.4 flywheel ----------------------------------------------------------------

def test_flywheel_pairs_from_round(tmp_path):
    lab = SimulatorLab(seed=3)
    p = make_protocol()
    result = lab.fetch_results(lab.submit_protocol(p))
    log = FlywheelLog(tmp_path / "train.jsonl")
    example = log.pair_from_round(p, result)
    loaded = log.load()
    assert len(loaded) == 1
    assert example["labels"][0]["value"] == result.measurements[0].value
    assert "protocol_id" in example["input"]


def test_campaign_recording_playbacks(tmp_path):
    """Full-flow field recording replays identically offline (P8)."""
    rec_path = Path("examples/_campaign_recording.json")
    if not rec_path.exists():
        pytest.skip("run examples/full_campaign.py first")
    pb = PlaybackLab(rec_path)
    caps = pb.list_capabilities()
    assert caps["assays"]
    # replay every recorded run
    import json as _json
    entries = _json.loads(rec_path.read_text())
    runs = [e["run_id"] for e in entries if e["op"] == "fetch_results"]
    assert runs
    for run_id in runs:
        result = pb.fetch_results(run_id)
        assert result.measurements


def test_hypothesis_lifecycle_recorded(tmp_path):
    from bionexus.core.hypothesis import HypothesisTracker
    from bionexus.core.contracts import EventType as ET

    store = SqliteProvenanceStore()
    tracker = HypothesisTracker(store, system_actor())
    lab = SimulatorLab(seed=5)
    p = make_protocol()
    result = lab.fetch_results(lab.submit_protocol(p))
    h = tracker.propose("C1 >= 50 binding", candidate="C1", assay_type="binding",
                        predicted=">= 50", predicted_value=50.0)
    tracker.attach_test(h, p, result.run_id)
    h = tracker.verdict(h, result, threshold=50.0)
    assert h.status in ("validated", "invalidated") and h.observed_value is not None
    events = [r.event_type.value for r in store.branch_records(h.branch_id)]
    assert events == ["hypothesis_proposed", "hypothesis_tested",
                      "hypothesis_validated" if h.status == "validated" else "hypothesis_invalidated"]


# ---- domain realism: dose-response, counterscreen, MPO ------------------------

def test_dose_response_monotonic_and_ic50_present():
    from bionexus.adapters.lab.simulator import SimulatorLab
    lab = SimulatorLab(seed=11)
    p = ProtocolSubmission(
        envelope=env(), title="dr", assay_type="binding",
        steps=[ProtocolStep(seq=1, op=ProtocolOp.dispense)],
        samples=[SampleSpec(sample_id="C1", kind=SampleKind.compound, concentration=c)
                 for c in ["1uM", "5uM", "25uM", "50uM"]],
    )
    r = lab.fetch_results(lab.submit_protocol(p))
    vals = [m.value for m in r.measurements]
    assert all(v2 >= v1 - 6 for v1, v2 in zip(vals, vals[1:])), "response grows with dose"
    assert all("ic50_um" in m.derived_metrics for m in r.measurements)


def test_countscreen_flags_interferers():
    from bionexus.adapters.lab.simulator import SimulatorLab
    lab = SimulatorLab(seed=11)
    comps = [f"X{i}" for i in range(24)]
    p = ProtocolSubmission(
        envelope=env(), title="cs", assay_type="counterscreen",
        steps=[ProtocolStep(seq=1, op=ProtocolOp.dispense)],
        samples=[SampleSpec(sample_id=c, kind=SampleKind.compound, concentration="10uM") for c in comps],
    )
    p.protocol_id = "fixed-cs-test"  # interference seeding keys off run/protocol id
    r = lab.fetch_results(lab.submit_protocol(p))
    by = {m.sample_id: m.value for m in r.measurements}
    hits = [c for c, v in by.items() if v > 20]
    assert hits, "seeded interference should catch some compounds"


def test_mpo_score_bounds():
    from examples.full_campaign import mpo_score
    assert mpo_score(0.1, 1.0, 0.9, True) > mpo_score(25.0, 0.2, 0.3, False)
    assert 0.0 <= mpo_score(50, 0.1, 0.1, False) <= 1.0


# ---- MCP server ------------------------------------------------------------------

def test_mcp_session_initialize_and_tools():
    from bionexus.mcp_server import McpSession

    s = McpSession()
    init = s.handle({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
    assert init["result"]["serverInfo"]["name"] == "bionexus"
    tools = s.handle({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
    names = {t["name"] for t in tools["result"]["tools"]}
    assert {"generate_candidates", "run_assay", "propose_hypothesis", "list_lab_capabilities"} <= names


def test_mcp_tool_calls():
    from bionexus.mcp_server import McpSession

    s = McpSession()
    call = lambda n, a: s.handle({"jsonrpc": "2.0", "id": 3, "method": "tools/call",
                                  "params": {"name": n, "arguments": a}})["result"]["content"][0]["text"]
    gen = json.loads(call("generate_candidates", {"target": "KRAS_G12C", "n": 2}))
    assert len(gen) == 2
    assay = json.loads(call("run_assay", {"compounds": ["CCO"], "assay": "binding"}))
    assert assay["results"]["CCO"]["ic50_um"] is not None
    hyp = json.loads(call("propose_hypothesis",
                          {"statement": "CCO >= 50 binding", "candidate": "CCO",
                           "assay_type": "binding", "predicted": ">= 50"}))
    assert hyp["status"] == "proposed"
    caps = json.loads(call("list_lab_capabilities", {}))
    assert "binding" in caps["assays"]
    err = s.handle({"jsonrpc": "2.0", "id": 4, "method": "nope"})
    assert err["error"]["code"] == -32601


# ---- HTML report -------------------------------------------------------------------

def test_report_html(tmp_path):
    import subprocess, sys
    subprocess.run([sys.executable, "examples/full_campaign.py"], capture_output=True)
    out = tmp_path / "report.html"
    r = subprocess.run([sys.executable, "-m", "bionexus.cli", "prove", "campaign-root",
                        "--db", "campaign.db", "--html", str(out)], capture_output=True, text=True)
    assert out.exists()
    html = out.read_text()
    assert "chain intact" in r.stdout and "ok" in html
    assert "hypothesis" in html and "BioNexus" in html


# ---- benchmark harness (offline fixture) -----------------------------------------

def test_benchmark_harness_offline(tmp_path):
    from bionexus.benchmark import CharRidgePolicy, MeanPolicy, RandomPolicy, run_benchmark

    class FixtureDataset:
        name, task = "fixture", "regression"

        def load(self):
            rng = __import__("random").Random(0)
            for _ in range(120):
                n = rng.randint(2, 10)
                yield "C" * n + "O", float(n) * 0.5 + rng.gauss(0, 0.05)

    ds = FixtureDataset()
    res = run_benchmark(ds, [RandomPolicy(), MeanPolicy(), CharRidgePolicy(dim=64)],
                        out=tmp_path / "b.json")
    assert res["policies"]["char3gram-ridge"]["spearman"] > 0.8, "linear signal must be learnable"
    assert res["policies"]["random"]["spearman"] < 0.3, "random must be a floor"
    assert (tmp_path / "b.json").exists()


# ---- benchmark metrics + LLM policy parsing ---------------------------------------

def test_roc_auc_correct_with_ties():
    from bionexus.benchmark import roc_auc
    assert roc_auc([0.9, 0.8, 0.7, 0.1], [1, 1, 0, 0]) == 1.0
    assert roc_auc([0.1, 0.2, 0.7, 0.9], [1, 1, 0, 0]) == 0.0
    assert roc_auc([0.5, 0.5, 0.5, 0.5], [1, 1, 0, 0]) == 0.5  # ties -> chance
    assert 0.0 <= roc_auc([0.3, 0.6, 0.4, 0.7], [1, 0, 0, 1]) <= 1.0


def test_llm_policy_parse_only():
    from bionexus.adapters.models.llm_policy import AnthropicLLMPolicy
    assert AnthropicLLMPolicy._parse('{"value": -1.42}') == -1.42
    assert AnthropicLLMPolicy._parse("The answer is 3.54 (logD).") == 3.54
    try:
        AnthropicLLMPolicy._parse("no numbers here")
        raised = False
    except ValueError:
        raised = True
    assert raised


# ---- imaging virtual lab (lab-imaging extra) ---------------------------------------

def test_imaging_lab_recovers_ic50_and_qc(tmp_path):
    np = pytest.importorskip("numpy")
    from bionexus.adapters.lab.imaging import ImagingSimulatorLab, true_ic50_um

    lab = ImagingSimulatorLab(seed=5, image_dir=str(tmp_path / "imgs"))
    p = ProtocolSubmission(
        envelope=env(), title="img", assay_type="binding",
        steps=[ProtocolStep(seq=1, op=ProtocolOp.dispense)],
        samples=[SampleSpec(sample_id=c, kind=SampleKind.compound, concentration=k)
                 for c in ["C1", "C2"] for k in ["0.5uM", "2uM", "10uM", "40uM"]]
        + [SampleSpec(sample_id="ctrl-neg", kind=SampleKind.buffer, concentration="10uM"),
           SampleSpec(sample_id="ctrl-neg2", kind=SampleKind.buffer, concentration="10uM")],
        reagents=[ReagentSpec(name="buffer", amount="1 mL", bsl_level=1)],
    )
    r = lab.fetch_results(lab.submit_protocol(p))
    assert r.qc.controls_passed
    assert r.qc.z_prime >= 0.3
    for m in r.measurements:
        truth = true_ic50_um(5, m.sample_id)
        assert abs(m.value - truth) / truth < 0.5, "IC50 recovery within 50% of truth"
    images = list((tmp_path / "imgs").glob("*.npy"))
    assert images, "raw plate images persisted as evidence"
    assert np.load(images[0]).shape == (24, 24)


def test_imaging_lab_dose_response_monotonic(tmp_path):
    pytest.importorskip("numpy")
    from bionexus.adapters.lab.imaging import (ImagingPlateReader, true_ic50_um,
                                               hill_response)
    dev = ImagingPlateReader(seed=9)
    concs = [0.5, 2.0, 10.0, 40.0]
    spec = [(f"A{i+1}", "C1", c) for i, c in enumerate(concs)]
    plate = dev.capture("monotonic-run", spec)
    ic50 = true_ic50_um(9, "C1")
    responses = [hill_response(c, ic50) for c in concs]
    assert all(b >= a for a, b in zip(responses, responses[1:])), "Hill curve is monotonic"


# ---- device sims (numpy extra) ------------------------------------------------------

def test_liquid_handler_low_volume_and_carryover(tmp_path):
    np = pytest.importorskip("numpy")
    from bionexus.adapters.lab.devices import LiquidHandlerSim
    from bionexus.core.contracts import ProtocolOp as PO

    lh = LiquidHandlerSim(seed=3)
    steps = [ProtocolStep(seq=1, op=PO.dispense, params={"volume_ul": 100}),
             ProtocolStep(seq=2, op=PO.dispense, params={"volume_ul": 1})]
    proto = ProtocolSubmission(envelope=env(), title="lh", assay_type="binding",
                               steps=steps,
                               samples=[SampleSpec(sample_id="C1", kind=SampleKind.compound)],
                               reagents=[ReagentSpec(name="b", amount="1 mL", bsl_level=1)])
    proto.protocol_id = "fixed-lh-test"  # device seeding keys off protocol id
    res = lh.execute(proto)
    t1, t2 = res["transfers"]
    assert abs(t1["error_percent"]) < 15  # cv=5%: 2-sigma bound
    assert t2["below_spec"] and t2["error_percent"] < 0  # systematic under-delivery


def test_sequencer_calls_planted_mutation(tmp_path):
    pytest.importorskip("numpy")
    from bionexus.adapters.lab.devices import SequencerSim

    seq = SequencerSim(seed=2)
    ref = "ACGT" * 15
    out = seq.sequence("s1", ref, [(20, "T")], coverage=30)
    calls = SequencerSim.call_variants(out["fastq"], ref)
    assert any(c["position"] == 20 and c["alt"] == "T" and c["fraction"] > 0.8
               for c in calls), "planted mutation must be recovered"
    assert all(c["position"] != 5 for c in calls), "no spurious high-freq calls"


def test_hypothesis_design_and_inconclusive(tmp_path):
    from bionexus.core.hypothesis import (ExperimentDesign, HypothesisTracker,
                                          SuccessCriteria)
    from bionexus.core.contracts import AssayResult, Envelope, InstrumentInfo, RunStatus

    store = SqliteProvenanceStore()
    tracker = HypothesisTracker(store, system_actor())
    h = tracker.propose(
        statement="C1 IC50 <= 20 uM", candidate="C1", assay_type="binding",
        predicted="IC50 <= 20", predicted_value=20.0, rationale="strong SAR precedent",
        criteria=SuccessCriteria(metric="ic50_um", direction="min", threshold=20.0),
        design=ExperimentDesign(assay_type="binding", concentrations=["0.5uM", "10uM", "40uM"],
                                replicates=3, controls=["negative"]),
    )
    assert h.status == "proposed" and h.criteria.threshold == 20.0
    assert h.design.concentrations == ["0.5uM", "10uM", "40uM"]

    # QC-failed run must be inconclusive, never a silent invalidate
    bad = AssayResult(envelope=env(), protocol_id="p", run_id="r-bad",
                      instrument=InstrumentInfo(adapter="sim", instrument_id="i"),
                      status=RunStatus.completed, measurements=[],
                      qc={"controls_passed": False})
    h = tracker.verdict(h, bad)
    assert h.status == "inconclusive" and h.qc_passed is False
